
module finalsOOP {
	requires java.desktop;
}